import { prisma } from '../prisma.js';

export const criarProduto = async (req, res) => {
  const { nome, descricao, preco, imagem } = req.body;
  if (!nome || preco == null) {
    return res.status(400).json({ error: 'Nome e preço são obrigatórios.' });
  }
  try {
    const produto = await prisma.produto.create({
      data: { nome, descricao, preco: parseFloat(preco), imagem }
    });
    res.status(201).json(produto);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Erro ao criar produto.' });
  }
};

export const lerProdutos = async (req, res) => {
  try {
    const lista = await prisma.produto.findMany();
    res.json(lista);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Erro ao listar produtos.' });
  }
};

export const atualizarProduto = async (req, res) => {
  const id = Number(req.params.id);
  const { nome, descricao, preco, imagem } = req.body;
  try {
    const atualizado = await prisma.produto.update({
      where: { id },
      data: { nome, descricao, preco: parseFloat(preco), imagem }
    });
    res.json(atualizado);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Erro ao atualizar produto.' });
  }
};

export const deletarProduto = async (req, res) => {
  const id = Number(req.params.id);
  try {
    await prisma.produto.delete({ where: { id } });
    res.json({ message: 'Produto removido com sucesso.' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Erro ao remover produto.' });
  }
};

export const buscarProdutoPorId = async (req, res) => {
  const id = Number(req.params.id);
  try {
    const produto = await prisma.produto.findUnique({ where: { id } });
    if (!produto) {
      return res.status(404).json({ error: 'Produto não encontrado.' });
    }
    res.json(produto);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Erro ao buscar produto.' });
  }
};
