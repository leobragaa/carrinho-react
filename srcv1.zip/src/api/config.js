export const API_BASE_URL = "http://localhost:3002/api";
export const UPLOAD_URL   = "http://localhost:3002/api/upload";

